class FirstClass {
    public static void main(string args[]) {
        system.out.println("hello world");
    }
}